from django.views.generic import TemplateView
from django.http import HttpResponse
from django.template import loader
from shop.models import Product

class IndexView(TemplateView):
    template_name = "shop/index.html"

    def get(self, request):
        products = Product.objects.order_by("name")
        for p in products:
            print(p)
        context = {"products":[
            {"name": "Product 1", "price": 1.5},
            {"name": "Product 2", "price": 2.75},
            {"name": "Product 3", "price": 6}
        ]}
        template = loader.get_template(self.template_name)
        return HttpResponse(template.render(context, request))